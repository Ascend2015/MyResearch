import cn.tj212.yin.entity.SomePath;
import cn.tj212.yin.service.ShortSetGenerateService;
import cn.tj212.yin.utils.IOUtils;
import cn.tj212.yin.utils.Parser;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("/spring/applicationContext.xml")
public class Test05 {

    @Autowired
    private SomePath somePath;

    @Test
    public void printSomePath(){
        Parser p=new Parser();
        try {
            p.getTrainingSet(somePath.getPssmPath(),somePath.getSecStrPath(),somePath.getOutPutPath(),somePath.getSpssmPath(),somePath.getBlastPath());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void getOnlyPSSM(){
        ShortSetGenerateService s=new ShortSetGenerateService();
        File file=new File("D:\\MyProteinData\\fasta\\tiny2016Zhoustrc");
        String[] fileList=file.list();
        for (String fileName:fileList
             ) {
            s.getShortTestSetOnlyPSSM("D:\\MyProteinData\\fasta\\tiny2016Zhoustrc"+File.separator+fileName,
                    "D:\\MyProteinData\\PSSM\\shorttiny2016","D:\\MyProteinData\\TestSet\\tiny2016OnlyShortPSSM.txt");
        }
    }

    @Test
    public void crossValidatePssmAndSPSSM(){
        Parser p=new Parser();
        String profileDir="D:\\MyProteinData\\fasta\\crossValidate\\cv5\\cv5triain\\cv5trainProfilestrc";
        String pssmDir="D:\\MyProteinData\\PSSM\\25percentR1.8";
        String spssmDir="D:\\MyProteinData\\SPSSM\\R1P82015Zhou";
        String outputDir="D:\\MyProteinData\\TestSet\\cv5train.txt";
        try {
            p.trainSetWithCtxPssmAndSPSSM(profileDir,pssmDir,spssmDir,outputDir);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void crossValidate(){
        List<String>[] testSetIds= IOUtils.randomFile("D:\\MyProteinData\\fasta\\trainProfilestrc");
        for (int j=0;j<5;j++
             ) {
            System.out.println("==============================================");
            for (int i = 0; i < testSetIds[j].size(); i++) {
                String filename=testSetIds[j].get(i);
                System.out.println(filename.substring(0,filename.lastIndexOf(".")));
            }
        }
    }
}
