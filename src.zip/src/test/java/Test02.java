import cn.tj212.yin.utils.Parser;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import cn.tj212.yin.service.ShortSetGenerateService;
import cn.tj212.yin.utils.IOUtils;

import java.io.File;
import java.io.IOException;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("/spring/*.xml")
public class Test02 {

    @Autowired
    private ShortSetGenerateService shortSetGenerateService;


    @Test
    public void testShortgetter(){
        ShortSetGenerateService shortSetGenerateService =new ShortSetGenerateService();
        String seqPath="D:\\MyProteinData\\fasta\\tiny2016Zhoustrc";
        String pssmPath="D:\\MyProteinData\\PSSM\\tiny2016";
        String outPath="D:\\MyProteinData\\tinyTest\\forStatistics\\sta.txt" ;
        String spssmPath="D:\\MyProteinData\\tinyTest\\spssm";
        File percent25For2016=new File(seqPath);
        String[] IdList=percent25For2016.list();
        for (int i=0;i<IdList.length;i++){
            shortSetGenerateService.getShortTestSet(seqPath+File.separator+IdList[i],pssmPath,outPath,spssmPath);
        }
    }

    @Test
    public void calNoSpssm(){
        try {
            List<String> lines=IOUtils.readFile("D:\\MyProteinData\\tinyTest\\forStatistics\\sta.txt");
            int c=0;
            for (int i = 0; i <lines.size() ; i++) {
                if (lines.get(i).contains("0.00\t0.00\t0.00\t0.00"))
                    c++;
            }
            System.out.println(c);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @Test
    public void getNewSpssmTestSet(){
        //ShortSetGenerateService shortSetGenerateService =new ShortSetGenerateService();
        String seqPath="D:\\CASP12\\casp12Zhoustrc";
        String pssmPath="D:\\CASP12\\shortSpssm";
        String outPath="D:\\MyProteinData\\TestSet\\caspshort20180327.txt" ;
        String blast="D:\\CASP12\\9merblast";
        int n =10;
        File percent25For2016=new File(seqPath);
        String[] IdList=percent25For2016.list();
        for (int i=0;i<IdList.length;i++){
            shortSetGenerateService.getShortTestSet(seqPath+File.separator+IdList[i],pssmPath,outPath,blast,n);
        }
    }


    @Test
    public void esemble(){
        String shortPssmPath="J:\\SciencePDB\\9merpssm";
        String shortOutPath="D:\\MyProteinData\\TestSet\\6EZOAshort.txt" ;
        String shortBlast="J:\\SciencePDB\\9merblast";
        Parser p = new Parser();
        String pssmPath = "J:\\SciencePDB\\pssm";
        String secStrcPath = "J:\\SciencePDB\\sciencestrc";
        String longOutputPath = "D:\\MyProteinData\\TestSet"+ File.separator + "6EZOA.txt";
        String spssmPath = "J:\\SciencePDB\\spssm";
        String mixFilePath="J:\\SciencePDB\\test\\6ezoATest.txt";
        int n =10;
        File percent25For2016=new File(secStrcPath);
        String[] IdList=percent25For2016.list();
        for (int i=0;i<IdList.length;i++){
            shortSetGenerateService.getShortTestSet(secStrcPath+File.separator+IdList[i],shortPssmPath,shortOutPath,shortBlast,n);
        }
        try {
            p.getTrainingSet(pssmPath, secStrcPath, longOutputPath , spssmPath);
            IOUtils.switchLine(shortOutPath,longOutputPath,mixFilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void onlyNewSPSSM(){
        File file=new File("D:\\CASP12\\casp12Zhoustrc");
        String[] fileList=file.list();
        for (String fileName:fileList
                ) {
            shortSetGenerateService.getShortTestSetOnlyNewSPSSM("D:\\CASP12\\casp12Zhoustrc"+File.separator+fileName,
                    "D:\\MyProteinData\\TestSet\\casp12OnlyShortSPSSM.txt","D:\\CASP12\\9merblast",10);
        }
    }

    @Test
    public  void renameFile(){
        String filePath="J:\\PDB_99";
        File file=new File(filePath);
        String[] fileList=file.list();
        for (String fileName:fileList){
            if (fileName.startsWith("pdb")){
                File item=new File(filePath+File.separator+fileName);
                item.renameTo(new File(filePath+File.separator+fileName.substring(3,fileName.length())));
            }
        }
    }

    @Test
    public  void deleteFile(){
        String filePath="J:\\PDB_99";
        File file=new File(filePath);
        String[] fileList=file.list();
        for (String fileName:fileList){
            if (fileName.length()>10){
                System.out.println(fileName);
                new File(filePath+File.separator+fileName).delete();
            }
        }
    }
}
