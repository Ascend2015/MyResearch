import cn.tj212.yin.service.ShortSetGenerateService;
import cn.tj212.yin.utils.IOUtils;
import cn.tj212.yin.utils.Parser;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("/spring/*.xml")
public class Test04 {

    @Autowired
    private ShortSetGenerateService shortSetGenerateService;

    @Test
    public void readCB513(){
        try {
            List<String> cb513list=IOUtils.readFile("D:\\MyProteinData\\CB513\\CB513.txt");
            for (String line:cb513list
                 ) {
                System.out.println(line.substring(0,6).toUpperCase().replace(" ",""));
                String ID=line.substring(0,6).toUpperCase().replace(" ","");
                IOUtils.writeAppend("D:\\MyProteinData\\CB513\\testID.txt",ID);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void caspParseDomain(){
        ParseForDssp parse=new ParseForDssp();
        try {
            parse.parseCaspDssp("D:\\MyProteinData\\CASP12Domain\\DomainDssp","D:\\MyProteinData\\CASP12Domain\\IntegerFile.txt","D:\\MyProteinData\\CASP12Domain\\singleFile");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void onlySPSSM(){
        Parser p=new Parser();
        try {
            p.trainingSetOnlySPSSM("D:\\CASP12\\casp12Zhoustrc",
                    "D:\\MyProteinData\\SPSSM\\casp12Zhou","D:\\MyProteinData\\TestSet\\Casp12OnlySPSSM.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testBlusomScore(){
        String testSegment="ARNDCQEGHILKMFPSTWYVBZX";
        Parser p=new Parser();
        try {
            p.addBlusom62(testSegment);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
