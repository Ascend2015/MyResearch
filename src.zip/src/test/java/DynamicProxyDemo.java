public class DynamicProxyDemo {
    public static void main(String[] args){

    }
}
