import cn.tj212.yin.dao.SMMSequenceDao;
import cn.tj212.yin.entity.SMMSequence;
import cn.tj212.yin.service.SMMSequenceService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@ContextConfiguration("/spring/*.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class TestSMMSequenceService {

    @Autowired
    private SMMSequenceService smmSequenceService;

    @Test
    public void getSMMSequence(){
        SMMSequence smmSequence=smmSequenceService.findBySerialNo(2l);
        System.out.println(smmSequence.getSequence());
        smmSequenceService.updateBySerailNo(smmSequence);
    }
}
