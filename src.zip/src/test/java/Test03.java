import cn.tj212.yin.utils.Parser;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import cn.tj212.yin.utils.IOUtils;
import cn.tj212.yin.utils.SeqUtils;

import java.io.File;
import java.io.IOException;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("/spring/applicationContext.xml")
public class Test03 {
    @Test
    public void integrate() {
        String dsspPath = "D:\\MyProteinData\\25percent2016DSSP";
        String picesPath = "D:\\MyProteinData\\2016data\\R13.txt";
        String outPath = "D:\\MyProteinData\\2016data\\R13Tml.txt";
        String strcPath = "D:\\MyProteinData\\fasta\\tiny2016";

        ParseForDssp parseDssp = new ParseForDssp();
        try {
            parseDssp.readData(dsspPath, picesPath, outPath, strcPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void get9merFasta() {
        Parser p = new Parser();
        //p.generate9merFasta("D:\\MyProteinData\\fasta\\4EDGA\\sectrc","D:\\MyProteinData\\fasta\\4EDGA\\9merFasta");
        p.generate9merFasta("D:\\MyProteinData\\CASP12Domain\\singleFilestrc", "D:\\MyProteinData\\CASP12Domain\\shortfasta");
    }

    String seqPath = "D:\\MyProteinData\\fasta\\3IFNP\\secstrc\\3IFNP";
    String outPath = "D:\\MyProteinData\\fasta\\3IFNP\\ShortTest\\shortTest01.txt";

    public void getSetByBlusom62(String seqPath, String outPath) {

        SeqUtils seqUtils = new SeqUtils();
        try {
            List<String> list = IOUtils.readFile(seqPath);
            String seq = "xxxx" + list.get(1) + "oooo";
            String strc = "xxxx" + list.get(2) + "oooo";
            StringBuilder outLine = new StringBuilder("");
            for (int i = 4; i < seq.length() - 4; i++) {
                String score = seqUtils.getBlusom62Score(seq.substring(i, i + 1));
                outLine.append(seq.substring(i, i + 1) + "\t" + seqUtils.splitByTab(seq.substring(i - 4, i + 5)) + score + "\t" + strc.substring(i, i + 1) + "\n");
            }
            IOUtils.writeAppend(outPath, outLine.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void getBlusom62SetAll() {
        String seqPath = "D:\\CASP12\\casp12fastastrcstrc";
        String outPath = "D:\\MyProteinData\\TestSet\\testSetBlusom.txt";
        File file = new File(seqPath);
        String[] IDArr = file.list();
        for (int i = 0; i < IDArr.length; i++) {
            getSetByBlusom62(seqPath + File.separator + IDArr[i], outPath);
        }
    }

    @Test
    public void LongPssm() {
        Parser p = new Parser();
        String pssmPath = "D:\\CASP12\\casp12pssm";
        String secStrcPath = "D:\\CASP12\\caspCorrectstrc";
        String outputPath = "D:\\MyProteinData\\TestSet";
        String spssmPath = "D:\\CASP12\\CASP12CorrectSPSSM";
        try {
            p.getTrainingSet(pssmPath, secStrcPath, outputPath + File.separator + "CaspCorrect.txt", spssmPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void getTrain() {
        Parser p = new Parser();
        String pssmPath = "D:\\MyProteinData\\PSSM\\tiny2016";
        String secStrcPath = "D:\\MyProteinData\\fasta\\tiny2016Zhoustrc";
        String outputPath = "D:\\MyProteinData\\TestSet";
        try {
            p.getTrainingSetOnlyPssm(pssmPath, secStrcPath, outputPath + File.separator + "tiny2016OnlyPSSM180407.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void delete() {
        IOUtils.deleteFile("D:\\MyProteinData\\fasta\\9mer2015_90per_strc");
    }

    @Test
    public void cutdown(){
        try {
            List<String> seq=IOUtils.readFile("J:\\SciencePDB\\science\\6EZOA.txt");
            SeqUtils.cutNine(seq.get(1),"J:\\SciencePDB\\9mer");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
