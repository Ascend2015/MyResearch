import cn.tj212.yin.service.ShortSetGenerateService;
import cn.tj212.yin.utils.IOUtils;
import cn.tj212.yin.utils.Parser;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.*;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("/spring/applicationContext.xml")
public class Test01 {

    @Autowired
    private Parser p;

    @Test
    public  void testParsePssm(){
        try {
            //p.getTrainingSet("D:\\MyProteinData\\PSSM\\25percentR1.8","D:\\MyProteinData\\fasta\\dsspToFasta25percent2");
            File file=new File("D:\\MyProteinData\\PSSM\\25percentR1.8");
            FileOutputStream fileOutputStream=new FileOutputStream("D:\\MyProteinData\\TestSet\\"+File.separator+"trainOnlyPSSM.txt",true);
            OutputStreamWriter outputStreamWriter=new OutputStreamWriter(fileOutputStream);
            String[] fileNames=file.list();
            for (int i = 0; i < fileNames.length; i++) {
                int dotIdx=fileNames[i].lastIndexOf(".");
                List<String> testSet=p.parsePSSM("D:\\MyProteinData\\PSSM\\25percentR1.8"+File.separator+fileNames[i]);
                List<String> profileContent= IOUtils.readFile("D:\\MyProteinData\\fasta\\trainProfilestrc"+File.separator+fileNames[i].substring(0,dotIdx)+".txt");
                String sequence=profileContent.get(1);
                String secStrc=profileContent.get(2);
                String TMP="";
                for (int j = 0; j <testSet.size() ; j++) {
                    TMP=TMP+sequence.substring(j,j+1)+"\t"+testSet.get(j)+"\t"+secStrc.substring(j,j+1)+"\n";
                }
                outputStreamWriter.write(TMP+"\n");
                outputStreamWriter.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
