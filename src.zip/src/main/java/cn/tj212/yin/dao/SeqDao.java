package cn.tj212.yin.dao;

import cn.tj212.yin.entity.Seg;

import java.io.Serializable;
import java.util.List;

public interface SeqDao extends Serializable {

    public Seg findBySegThreeStr(String seg);

    public Seg findBySegFiveStr(String seg);

    public Seg findBySegSevenStr(String seg);

    public List<Seg> findByCenterThree(String seg);

    public List<Seg> findByCenterFive(String seg);
}
