package cn.tj212.yin.dao;

import cn.tj212.yin.entity.SMMSequence;

import java.util.List;

public interface SMMSequenceDao {

    List<SMMSequence> findByNotPrepared();

    SMMSequence selectBySerialNo(Long serialNo);

    SMMSequence selectByID(String id);

    void updateBySerailNo(SMMSequence sequence);
}
