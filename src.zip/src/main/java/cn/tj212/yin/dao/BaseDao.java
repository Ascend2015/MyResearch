package cn.tj212.yin.dao;

import java.io.Serializable;

public interface BaseDao extends Serializable {

}
