package cn.tj212.yin.service;

import cn.tj212.yin.dao.BaseDao;
import cn.tj212.yin.dao.SeqDao;
import cn.tj212.yin.entity.Seg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.SQLException;

@Service
public class CheckService {

    @Autowired
    private SeqDao seqDao;

    public Seg findBySegThree(String seg){
            Seg segTarget=seqDao.findBySegThreeStr(seg);
            return segTarget;
    }

    public Seg findBySegFive(String seg){
        return seqDao.findBySegFiveStr(seg);
    }
}
