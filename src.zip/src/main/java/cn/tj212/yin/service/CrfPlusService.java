package cn.tj212.yin.service;

import java.io.File;
import java.io.IOException;

public class CrfPlusService {

    private String defaultCrfDir="D:\\CRF.51";
    private String resultPath="";
    private String testsetPath="";
    private String trainsetPath="";

    public String getDefaultCrfDir() {
        return defaultCrfDir;
    }

    public void setDefaultCrfDir(String defaultCrfDir) {
        this.defaultCrfDir = defaultCrfDir;
    }

    public String getResultPath() {
        return resultPath;
    }

    public void setResultPath(String resultPath) {
        this.resultPath = resultPath;
    }

    public String getTestsetPath() {
        return testsetPath;
    }

    public void setTestsetPath(String testsetPath) {
        this.testsetPath = testsetPath;
    }

    public String getTrainsetPath() {
        return trainsetPath;
    }

    public void setTrainsetPath(String trainsetPath) {
        this.trainsetPath = trainsetPath;
    }

    public void predict(String modelName, String testsetDir, String resutlDir) throws IOException {
        File seqFile = new File(testsetDir);
        String crfPath = this.defaultCrfDir;
        String cmd = "crf_test.exe" + " -m" + modelName + " " + testsetDir + " -o " + resutlDir ;
        Runtime runtime = Runtime.getRuntime();
        Process p = runtime.exec(cmd, null, new File(crfPath));
    }

    public static void train(String templateName, String trainsetName, String modelName) throws IOException {

    }
}
