package cn.tj212.yin.service;

import cn.tj212.yin.dao.SMMSequenceDao;
import cn.tj212.yin.dao.SeqDao;
import cn.tj212.yin.entity.Seg;
import cn.tj212.yin.utils.Read9merStrcUtils;
import cn.tj212.yin.utils.SeqUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import cn.tj212.yin.utils.IOUtils;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service("shortService")
public class ShortSetGenerateService {

    private static Logger logger=LoggerFactory.getLogger(ShortSetGenerateService.class);

    @Autowired
    private SeqDao seqDao;

    @Autowired
    private SMMSequenceDao smmSequenceDao;

    private static final String AMINOACIDS = "ARNDCQEGHILKMFPSTWYVBZX*";

    /**
     * @param seqPath   序列及二级结构文件
     * @param shortPssm
     * @param outPath
     * @param blastPath
     * @param n         取n条Hit Sequences
     */
    public void getShortTestSet(String seqPath, String shortPssm, String outPath, String blastPath, int n) {
        try {
            Read9merStrcUtils cal = new Read9merStrcUtils();
            String seq = parseSeq(seqPath);
            String secStrc = getSecStrc(seqPath);
            //在序列前后加上o,x以表示左右空格
            //结构中不用加空格是因为下面在取结构时方法不同
            seq = "oooo" + seq + "xxxx";
            String outLine = "";
            StringBuffer tempBuilder = new StringBuffer("");
            for (int i = 4; i < seq.length() - 4; i++) {
                try {
                    //ratio可以是blast结果中前n条hit的三态比例
                    //System.out.println(seq.substring(i-4,i+5));
                    double[] ratioArr = cal.readBlast(blastPath + File.separator + seq.substring(i - 4, i + 5) + ".txt", n);
                    if (ratioArr == null) {
                        ratioArr = findBySegFive(seq.substring(i - 2, i + 3));
                        if (ratioArr == null) {
                            ratioArr = findBySegThree(seq.substring(i - 1, i + 2));
                        }
                    }
                    ratioArr = calratio(ratioArr);
                    String spssm = newSPSSMToStr(ratioArr, n);
                    String targetSeg=getFirstHit(blastPath,seq.substring(i - 4, i + 5));
//                    tempBuilder.append(seq.substring(i, i + 1) + "\t" + SeqUtils.getBlusomScoreBySeg(seq.substring(i - 4, i + 5),targetSeg)
//                            + parseShortPSSM(shortPssm + File.separator + seq.substring(i - 4, i + 5) + ".pssm") + spssm + "\t" + secStrc.substring(i - 4, i - 3) + "\n");
                    File file=new File(shortPssm + File.separator + seq.substring(i - 4, i + 5) + ".pssm");
                    if (!file.exists()){
                        //存在可能该切片没有获得PSSM，如果该切片没有PSSM存在则需要以blusom62矩阵代替
                        logger.warn(seq.substring(i - 4, i + 5)+" can not find pssm");
                        String[] blusomLine=SeqUtils.getBlusom62Score(seq.substring(i, i + 1)).split("\t");
                        StringBuffer scores=new StringBuffer("");
                        for (int j = 0; j < blusomLine.length-4; j++) {
                            scores.append(blusomLine[j]+"\t");
                        }
                        tempBuilder.append(seq.substring(i, i + 1) + "\t" + SeqUtils.splitByTab(seq.substring(i - 4, i + 5))
                                + scores.toString() + spssm + "\t" + secStrc.substring(i - 4, i - 3) + "\n");
                    }else {
                        tempBuilder.append(seq.substring(i, i + 1) + "\t" + SeqUtils.splitByTab(seq.substring(i - 4, i + 5))
                                + parseShortPSSM(shortPssm + File.separator + seq.substring(i - 4, i + 5) + ".pssm") + spssm + "\t" + secStrc.substring(i - 4, i - 3) + "\n");
                    }
                } catch (FileNotFoundException e) {

                    e.printStackTrace();
//                    double[] ratioArr = cal.readBlast(blastPath + File.separator + seq.substring(i - 4, i + 5) + ".txt", n);
//                    if (ratioArr == null) {
//                        ratioArr = findBySegFive(seq.substring(i - 2, i + 3));
//                        if (ratioArr == null)
//                            ratioArr = findBySegThree(seq.substring(i - 1, i + 2));
//                    }
//                    ratioArr = calratio(ratioArr);
//                    String spssm = newSPSSMToStr(ratioArr, n);
//                    String targetSeg=getFirstHit(blastPath,seq.substring(i - 4, i + 5));
//                    String[] blusomLine=SeqUtils.getBlusom62Score(seq.substring(i, i + 1)).split("\t");
//                    StringBuffer scores=new StringBuffer("");
//                    for (int j = 0; j < blusomLine.length-4; j++) {
//                        scores.append(blusomLine[j]+"\t");
//                    }
//                    tempBuilder.append(seq.substring(i, i + 1) + "\t" + SeqUtils.splitByTab(targetSeg)
//                            + scores.toString() + spssm + "\t" + secStrc.substring(i - 4, i - 3) + "\n");
                }
            }
            outLine = tempBuilder.toString();
            IOUtils.writeAppend(outPath, outLine);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void getShortTestSetOnlyNewSPSSM(String seqPath, String outPath, String blastPath, int n) {
        try {
            Read9merStrcUtils cal = new Read9merStrcUtils();
            String seq = parseSeq(seqPath);
            String secStrc = getSecStrc(seqPath);
            //在序列前后加上o,x以表示左右空格
            //结构中不用加空格是因为下面在取结构时方法不同
            seq = "oooo" + seq + "xxxx";
            String outLine = "";
            StringBuffer tempBuilder = new StringBuffer("");
            for (int i = 4; i < seq.length() - 4; i++) {
                try {
                    double[] ratioArr = cal.readBlast(blastPath + File.separator + seq.substring(i - 4, i + 5) + ".txt", n);
                    if (ratioArr == null) {
                        ratioArr = findBySegFive(seq.substring(i - 2, i + 3));
                        if (ratioArr == null) {
                            ratioArr = findBySegThree(seq.substring(i - 1, i + 2));
                        }
                    }
                    ratioArr = calratio(ratioArr);
                    String spssm = newSPSSMToStr(ratioArr, n);
                    tempBuilder.append(seq.substring(i, i + 1) + "\t"
                             + spssm + "\t" + secStrc.substring(i - 4, i - 3) + "\n");
                } catch (FileNotFoundException e) {
                    logger.warn(seq.substring(i - 4, i + 5)+" can not find pssm");
                    double[] ratioArr = cal.readBlast(blastPath + File.separator + seq.substring(i - 4, i + 5) + ".txt", n);
                    if (ratioArr == null) {
                        ratioArr = findBySegFive(seq.substring(i - 2, i + 3));
                        if (ratioArr == null)
                            ratioArr = findBySegThree(seq.substring(i - 1, i + 2));
                    }
                    ratioArr = calratio(ratioArr);
                    String spssm = newSPSSMToStr(ratioArr, n);
                    tempBuilder.append(seq.substring(i, i + 1) + "\t"
                            + spssm + "\t" + secStrc.substring(i - 4, i - 3) + "\n");
                }
            }
            outLine = tempBuilder.toString();
            IOUtils.writeAppend(outPath, outLine);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void getShortTestSetOnlyPSSM(String seqPath, String shortPssm, String outPath){
        try {
            String seq = parseSeq(seqPath);
            String secStrc = getSecStrc(seqPath);
            //在序列前后加上o,x以表示左右空格
            //结构中不用加空格是因为下面在取结构时方法不同
            seq = "oooo" + seq + "xxxx";
            String outLine = "";
            StringBuffer tempBuilder = new StringBuffer("");
            for (int i = 4; i < seq.length() - 4; i++) {
                try {
                    //System.out.println(seq.substring(i-4,i+5));
//                    tempBuilder.append(seq.substring(i, i + 1) + "\t" + SeqUtils.getBlusomScoreBySeg(seq.substring(i - 4, i + 5),targetSeg)
//                            + parseShortPSSM(shortPssm + File.separator + seq.substring(i - 4, i + 5) + ".pssm") + spssm + "\t" + secStrc.substring(i - 4, i - 3) + "\n");
                    tempBuilder.append(seq.substring(i, i + 1) + "\t"
                            + parseShortPSSM(shortPssm + File.separator + seq.substring(i - 4, i + 5) + ".pssm") + secStrc.substring(i - 4, i - 3) + "\n");
                } catch (FileNotFoundException e) {
                    //存在可能该切片没有获得PSSM，如果该切片没有PSSM存在则需要以blusom62矩阵代替
                    logger.warn(seq.substring(i - 4, i + 5)+" can not find pssm");
                    String[] blusomLine=SeqUtils.getBlusom62Score(seq.substring(i, i + 1)).split("\t");
                    StringBuffer scores=new StringBuffer("");
                    for (int j = 0; j < blusomLine.length-4; j++) {
                        scores.append(blusomLine[j]+"\t");
                    }
                    tempBuilder.append(seq.substring(i, i + 1) + "\t"
                            + scores.toString()  + secStrc.substring(i - 4, i - 3) + "\n");
                }
            }
            outLine = tempBuilder.toString();
            IOUtils.writeAppend(outPath, outLine);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 将二级结构转化为字符串输出
     *
     * @param doubleArr
     * @param n
     * @return
     * @throws IOException
     */
    private String newSPSSMToStr(double[] doubleArr, int n) throws IOException {
        double[] ratioOfStrc = doubleArr;
        String ratioToStr = String.format("%.2f", ratioOfStrc[0]) + "\t" + String.format("%.2f", ratioOfStrc[1]) + "\t" + String.format("%.2f", ratioOfStrc[2]);
        //System.out.println(ratioToStr);
        return ratioToStr;
    }

    private String getFirstHit(String blastPath,String segment) throws IOException {
        List<String> blastFileContent = IOUtils.readFile(blastPath+File.separator+segment+".txt");
        String blastFirstHit = "";
        for (int i = 0; i < blastFileContent.size(); i++) {
            if (blastFileContent.get(i).startsWith(">")) {
                blastFirstHit = blastFileContent.get(i).substring(2, 2 + segment.length());
                return blastFirstHit;
            }
        }
        //否则返回查询序列本身
        return segment;
    }

    /**
     * @param seqPath    序列及二级结构文件
     * @param shortPssm  短PSSM路径
     * @param outPath    输出路径
     * @param shortSpssm 短Spssm路径
     */
    public void getShortTestSet(String seqPath, String shortPssm, String outPath, String shortSpssm) {
        try {
            String seq = parseSeq(seqPath);
            String secStrc = getSecStrc(seqPath);
            //在序列前后加上ox以表示左右空格
            //结构中不用加空格是因为下面在取结构时方法不同
            seq = "oooo" + seq + "xxxx";
            String outLine = "";
            StringBuffer tempBuilder = new StringBuffer("");
            for (int i = 4; i < seq.length() - 4; i++) {
                try {
                    //System.out.println(seq.substring(i-4,i+5));
                    boolean flag = new File(shortSpssm + File.separator + seq.substring(i - 4, i + 5) + ".txt").exists();
                    seq.substring(i - 4, i + 5);
                    String spssm = "";
                    if (flag) {
                        spssm = getSPSSM(shortSpssm + File.separator + seq.substring(i - 4, i + 5));
                    } else {
                        //System.out.println(seq.substring(i - 4, i + 5));
                        spssm = "0.00\t0.00\t0.00";
                    }
                    tempBuilder.append(seq.substring(i, i + 1) + "\t" + SeqUtils.splitByTab(seq.substring(i - 4, i + 5))
                            + parseShortPSSM(shortPssm + File.separator + seq.substring(i - 4, i + 5) + ".pssm") + spssm + "\t" + secStrc.substring(i - 4, i - 3) + "\n");
                } catch (FileNotFoundException e) {
                    System.out.println(seq.substring(i - 4, i + 5));
                    System.out.println("can not find seq");
                    boolean flag = new File(shortSpssm + File.separator + seq.substring(i - 4, i + 5)).exists();
                    String spssm = "";
                    if (flag)
                        spssm = getSPSSM(shortSpssm + File.separator + seq.substring(i - 4, i + 5));
                    else
                        spssm = "0.00\t0.00\t0.00";
                    tempBuilder.append(seq.substring(i, i + 1) + "\t" + SeqUtils.splitByTab(seq.substring(i - 4, i + 5))
                            + SeqUtils.getBlusom62Score(seq.substring(i, i + 1)) + "\t" + spssm + "\t" + secStrc.substring(i - 4, i - 3) + "\n");
                }
            }
            outLine = tempBuilder.toString();
            IOUtils.writeAppend(outPath, outLine);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getSecStrc(String seqPath) throws IOException {
        FileInputStream fis = new FileInputStream(seqPath);
        InputStreamReader isrSeq = new InputStreamReader(fis);
        BufferedReader bfrSeq = new BufferedReader(isrSeq);

        String secStrc = "";
        List<String> lineList = new ArrayList<String>();
        while ((secStrc = bfrSeq.readLine()) != null) {
            lineList.add(secStrc);
        }
        secStrc = lineList.get(2);

        return secStrc;
    }

    public String parseShortPSSM(String shortPssm) throws IOException {
        FileInputStream fis = new FileInputStream(shortPssm);
        InputStreamReader isrPssm = new InputStreamReader(fis);
        BufferedReader pssmBr = new BufferedReader(isrPssm);

        List<String> lineList = new ArrayList<String>();
        List<String> PSSM = new ArrayList<String>();
        String line = "";

        while ((line = pssmBr.readLine()) != null) {
            lineList.add(line);
        }
        pssmBr.close();
        isrPssm.close();
        fis.close();
        for (int i = 3; i < lineList.size() - 1; i++) {
            if (lineList.get(i).length() > 1) {
                String[] pssmArr = lineList.get(i).split(" ");
                StringBuffer tmp = new StringBuffer("");
                Pattern p = Pattern.compile("-*\\d+(\\.\\d+)?");
                List<String> tmpList = new ArrayList<String>();
                for (String pssm : pssmArr
                        ) {
                    Matcher m = p.matcher(pssm);
                    if (m.find()) {
                        tmpList.add(m.group(0));
                    }
                }
                for (int j = 1; j < 21; j++) {
                    tmp.append(tmpList.get(j) + "\t");
                }
                PSSM.add(tmp.toString());
            } else {
                break;
            }
        }
        System.out.println(PSSM.get(4));
        return PSSM.get(4);
    }

    public String getSPSSM(String spssmpath) throws IOException {
        List<String> spssmList = IOUtils.readFile(spssmpath + ".txt");
        return spssmList.get(4);
    }

    public String parseSeq(String seqPath) throws IOException {
        FileInputStream fis = new FileInputStream(seqPath);
        InputStreamReader isrSeq = new InputStreamReader(fis);
        BufferedReader bfrSeq = new BufferedReader(isrSeq);

        String seq = "";
        List<String> lineList = new ArrayList<String>();
        while ((seq = bfrSeq.readLine()) != null) {
            lineList.add(seq);
        }
        seq = lineList.get(1);
        return seq;
    }

    public double[] findBySegThree(String seg) {
        Seg segTarget = seqDao.findBySegThreeStr(seg);
        System.out.println("three mer");
        double[] ratioArr = new double[4];
        ratioArr[0] = segTarget.getH().doubleValue();
        ratioArr[1] = segTarget.getE().doubleValue();
        ratioArr[2] = segTarget.getC().doubleValue();
        ratioArr[3] = segTarget.getB().doubleValue();
        return ratioArr;
    }

    /**
     *
     * @param seg
     * @return
     */
    public double[] findBySegFive(String seg) {
        Seg segT = seqDao.findBySegFiveStr(seg);
        System.out.println("five mer");
        //if (segT==null)
        //System.out.println(seg);
        double[] ratioArr = new double[4];
        return getDoubles(segT, ratioArr);
    }

    private double[] getDoubles(Seg segT, double[] ratioArr) {
        try {
            ratioArr[0] = segT.getH().doubleValue();
            ratioArr[1] = segT.getE().doubleValue();
            ratioArr[2] = segT.getC().doubleValue();
            ratioArr[3] = segT.getB().doubleValue();
            if (ratioArr[0] + ratioArr[1] + ratioArr[2] < 0.50) {
                return null;
            }
            return ratioArr;
        } catch (NullPointerException e) {
            return null;
        }
    }

    public double[] findBySegSeven(String seg) {
        Seg segT = seqDao.findBySegSevenStr(seg);
        System.out.println("seven mer");
        double[] ratioArr = new double[4];
        return getDoubles(segT, ratioArr);
    }

    private double[] calratio(double[] countsArr) {
        double totalFreqH = 0.00;
        double totalFreqE = 0.00;
        double totalFreqC = 0.00;
        double totalFreqB = 0.00;
        for (int i = 0; i < countsArr.length; i++) {
            totalFreqH += countsArr[0];
            totalFreqE += countsArr[1];
            totalFreqC += countsArr[2];
            //totalFreqB+=strcArr[3];
        }
        double totalCount = totalFreqH + totalFreqE + totalFreqC;
        double ratioOfH = totalFreqH / totalCount;
        double ratioOfE = totalFreqE / totalCount;
        double ratioOfC = totalFreqC / totalCount;

        double[] ratioArr = {ratioOfH, ratioOfE, ratioOfC};
        return ratioArr;
    }

    /**
     * 用以获取某个切片的blast对应blusom62分值
     *
     * @param segment
     * @throws IOException
     */
    //todo
    public void getBlusom62ScoreForSegment(String segment) throws IOException {

        String[] hitsFound=readBlastResult(segment);
        logger.info(hitsFound[0]+"\t"+hitsFound[1]);
        for (int i = 0; i < segment.length() - 1; i++) {
            
        }
    }

    //todo
    private String[] readBlastResult(String tragetSeg) throws IOException {
        List<String> blastResultLine = IOUtils.readFile("");
        String[] hits={};
        for (int i = 0; i < blastResultLine.size()-1; i++) {
            int j=0;
            if (blastResultLine.get(i).startsWith(">")){
                hits[j]=blastResultLine.get(i).trim();
                j++;
            }
        }
        return hits;
    }

    private void scoreForSeg() {

    }
}
