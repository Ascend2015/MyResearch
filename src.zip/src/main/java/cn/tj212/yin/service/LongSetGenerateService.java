package cn.tj212.yin.service;

import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LongSetGenerateService {
    public void readSequence(String fastaDir) throws IOException {
            File dsspDir=new File(fastaDir);
            String[] dsspList=dsspDir.list();

            FileInputStream fisFasta=new FileInputStream(fastaDir);
            InputStreamReader fastaIn=new InputStreamReader(fisFasta);
            BufferedReader fastaBr=new BufferedReader(fastaIn);
            String line="";
            String seq="";
            String ID="";
            while ((line=fastaBr.readLine())!=null){
                String reExp=">(\\w+)";
                Pattern patternID=Pattern.compile(reExp);
                Matcher m=patternID.matcher(line);
                if (m.find()){
                    //System.out.println(ID+"\t"+seq);
                    //ID;
                    //seq;
                    ID=m.group(1);
                    seq="";
                }else{
                    seq=seq+line;
                }
            }
    }
    //读取PSSM信息获得PSSM矩阵
    private void readPSSM(String ID,String pssmDir) throws IOException {
        FileInputStream fisFasta=new FileInputStream(pssmDir+File.separator);
        InputStreamReader fastaIn=new InputStreamReader(fisFasta);
        BufferedReader fastaBr=new BufferedReader(fastaIn);
    }

    public void gennerate(String ID,String sequence){

    }
}
