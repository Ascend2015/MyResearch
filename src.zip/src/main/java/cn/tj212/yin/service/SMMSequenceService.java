package cn.tj212.yin.service;

import cn.tj212.yin.dao.SMMSequenceDao;
import cn.tj212.yin.entity.SMMSequence;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SMMSequenceService {

    @Autowired
    private SMMSequenceDao smmSequenceDao;

    public SMMSequence findBySerialNo(Long serialNo){
        SMMSequence smmSequence=smmSequenceDao.selectBySerialNo(serialNo);
        return smmSequence;
    }

    public void updateBySerailNo(SMMSequence sequence){
        smmSequenceDao.updateBySerailNo(sequence);
    }
}
