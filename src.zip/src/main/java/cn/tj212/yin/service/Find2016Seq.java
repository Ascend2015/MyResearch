package cn.tj212.yin.service;

import cn.tj212.yin.utils.IOUtils;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Find2016Seq {
    public void find(String pices2016,String picesAll) throws IOException {

        String tmp="";
        List<String> picesLine2016= IOUtils.readFile(pices2016);
        List<String> picesLineAll=IOUtils.readFile(picesAll);
        String outLine="";
        List<String> excludeID=new ArrayList<String>();
        for (String line:picesLineAll
             ) {
            if (picesLine2016.contains(line.substring(0,4))){
                System.out.println(line.substring(0,5));
                outLine+=(line.substring(0,5)+"\n");
            }else {
                excludeID.add(line);
            }
        }
        FileOutputStream fileOutputStream=new FileOutputStream("D:\\MyProteinData\\2016data\\25percentOnly2016ID02.txt");
        OutputStreamWriter outputStreamWriter=new OutputStreamWriter(fileOutputStream);
        outputStreamWriter.write(outLine);
        outputStreamWriter.flush();
        String outLine2="";
        for (String line:excludeID
                ) {
            outLine2+=line.substring(0,5)+"\n";
        }
        FileOutputStream fos=new FileOutputStream("D:\\MyProteinData\\2016data\\modelID.txt");
        OutputStreamWriter osw=new OutputStreamWriter(fos);
        osw.write(outLine2);
        osw.flush();
    }

    public static void main(String[] args){
        try {
            File file=new File("D:\\MyProteinData\\shortDatabase");
            File file2=new File("D:\\MyProteinData\\PSSM\\25percentR1.8");
            String[] arr2016=file.list();
            String[] arr2015=file2.list();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}