package cn.tj212.yin.entity;

public class SomePath {
    private String blastPath;
    private String spssmPath;
    private String outPutPath;
    private String pssmPath;
    private String secStrPath;

    public String getBlastPath() {
        return blastPath;
    }

    public void setBlastPath(String blastPath) {
        this.blastPath = blastPath;
    }

    public String getSpssmPath() {
        return spssmPath;
    }

    public void setSpssmPath(String spssmPath) {
        this.spssmPath = spssmPath;
    }

    public String getPssmPath() {
        return pssmPath;
    }

    public void setPssmPath(String pssmPath) {
        this.pssmPath = pssmPath;
    }

    public String getSecStrPath() {
        return secStrPath;
    }

    public void setSecStrPath(String secStrPath) {
        this.secStrPath = secStrPath;
    }

    public String getOutPutPath() {
        return outPutPath;
    }

    public void setOutPutPath(String outPutPath) {
        this.outPutPath = outPutPath;
    }

    @Override
    public String toString() {
        return "SomePath{" +
                "blastPath='" + blastPath + '\'' +
                ", spssmPath='" + spssmPath + '\'' +
                ", outPutPath='" + outPutPath + '\'' +
                ", pssmPath='" + pssmPath + '\'' +
                ", secStrPath='" + secStrPath + '\'' +
                '}';
    }
}
