package cn.tj212.yin.entity;

import java.io.Serializable;

public class Seg implements Serializable {
    private String seg;

    private Integer H;

    private Integer C;

    private Integer E;

    private Integer B;

    private Double score;

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    public String getSeg() {
        return seg;
    }

    public void setSeg(String seg) {
        this.seg = seg;
    }

    public Integer getH() {
        return H;
    }

    public void setH(Integer h) {
        H = h;
    }

    public Integer getC() {
        return C;
    }

    public void setC(Integer c) {
        C = c;
    }

    public Integer getE() {
        return E;
    }

    public void setE(Integer e) {
        E = e;
    }

    public Integer getB() {
        return B;
    }

    public void setB(Integer b) {
        B = b;
    }

    @Override
    public String toString() {
        return "Seg{" +
                "seg='" + seg + '\'' +
                ", H=" + H +
                ", C=" + C +
                ", E=" + E +
                ", B=" + B +
                '}';
    }
}
