package cn.tj212.yin.entity;


import java.io.Serializable;

public class SMMSequence implements Serializable {

    private static final long serialVersionUID = 3375747161365155823L;

    private Long serialNo;

    private String sequenceId;

    private String sequence;

    private Integer isCalced;

    private Integer isLocked;

    private String locker;

    private Long jobId;

    private String predResult;

    private Integer failed;

    private Integer prepared;

    private Integer testsetOK;

    public Integer getTestsetOK() {
        return testsetOK;
    }

    public void setTestsetOK(Integer testsetOK) {
        this.testsetOK = testsetOK;
    }

    public Long getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(Long serialNo) {
        this.serialNo = serialNo;
    }

    public String getSequenceId() {
        return sequenceId;
    }

    public void setSequenceId(String sequenceId) {
        this.sequenceId = sequenceId;
    }

    public String getSequence() {
        return sequence;
    }

    public void setSequence(String sequence) {
        this.sequence = sequence;
    }

    public Integer getIsCalced() {
        return isCalced;
    }

    public void setIsCalced(Integer isCalced) {
        this.isCalced = isCalced;
    }

    public Integer getIsLocked() {
        return isLocked;
    }

    public void setIsLocked(Integer isLocked) {
        this.isLocked = isLocked;
    }

    public String getLocker() {
        return locker;
    }

    public void setLocker(String locker) {
        this.locker = locker;
    }

    public Long getJobId() {
        return jobId;
    }

    public void setJobId(Long jobId) {
        this.jobId = jobId;
    }

    public String getPredResult() {
        return predResult;
    }

    public void setPredResult(String predResult) {
        this.predResult = predResult;
    }

    public Integer getFailed() {
        return failed;
    }

    public void setFailed(Integer failed) {
        this.failed = failed;
    }

    public Integer getPrepared() {
        return prepared;
    }

    public void setPrepared(Integer prepared) {
        this.prepared = prepared;
    }

    @Override
    public String toString() {
        return "SMMSequence{" +
                "serialNo=" + serialNo +
                ", sequenceId='" + sequenceId + '\'' +
                ", sequence='" + sequence + '\'' +
                ", isCalced=" + isCalced +
                ", isLocked=" + isLocked +
                ", locker='" + locker + '\'' +
                ", jobId=" + jobId +
                ", predResult='" + predResult + '\'' +
                ", failed=" + failed +
                ", prepared=" + prepared +
                '}';
    }
}
