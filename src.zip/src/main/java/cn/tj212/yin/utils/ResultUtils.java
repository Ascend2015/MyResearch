package cn.tj212.yin.utils;

import java.io.IOException;
import java.util.List;

public class ResultUtils {
    public void getPredResult(String resultPath,String outputProfilePath) throws IOException {
        List<String> resultList=IOUtils.readFile(resultPath);
        String sequence="";
        String strc="";
        for (int i=0;i<resultList.size();i++){
            String amino=resultList.get(i).substring(0,1);
        }
    }
}
