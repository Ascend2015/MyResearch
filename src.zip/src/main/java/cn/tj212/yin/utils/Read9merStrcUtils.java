package cn.tj212.yin.utils;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;

public class Read9merStrcUtils {

    private static Logger logger= LoggerFactory.getLogger(Read9merStrcUtils.class);

    private static HashMap<String,int[]> nineMerMap=new HashMap<String, int[]>();

    //初始化该类，该类要将所有已知蛋白9mer与结构存储在HashMap中
    static {
        try {
            //List<String> template=IOUtils.readFile("D:\\YCKDATA\\2015_9mer\\2015_9MERALL.txt");
            List<String> template=IOUtils.readFile("F:\\javaPractise\\getTrainningSet\\src\\main\\resources\\nine_mer_zhou.txt");
            for (String temLine:template
                 ) {
                //数据库的所有记录存为文本，此处读出一行记录，存为数组
                String[] strs=temLine.split(",");
                int counts[]=new int[4];
                //数组的结构记录，也就是第2，3，4个元素作为结构信息存入新的int数组
                for (int i = 1; i < 5; i++) {
                    counts[i-1]=Integer.parseInt(strs[i]);
                }
                //数组的第一个元素作为键
                nineMerMap.put(strs[0],counts);
            }
            //System.out.println(nineMerMap.get("AADTSTDTS")[0]+"\t"+nineMerMap.get("AADTSTDTS")[1]+"\t"+nineMerMap.get("AADTSTDTS")[2]+"\t"+nineMerMap.get("AADTSTDTS")[3]);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 分析blast结果文件，找到Hit Sequence，读取前n行
     */
    public double[] readBlast(String blastRePath,int n) throws IOException {
        String seg=blastRePath.substring(blastRePath.lastIndexOf(".")-9,blastRePath.lastIndexOf("."));
        //先判断我们的9mer数据库中是否存在这样的blastRePath这样的键，如果没有，则交由5mer数据库处理
        if (nineMerMap.containsKey(seg)){
            //System.out.println("there's no 9merKey found:"+seg);
            List<String> blastLines=IOUtils.readFile(blastRePath);
            List<String> hitLines=new ArrayList<String>();
            for (int i = 0; i <blastLines.size() ; i++) {
                if (blastLines.get(i).contains("Sequences producing significant alignments")){
                    for (int j = i+2; j <blastLines.size() ; j++) {
                        //将该行以空格符切成字符数组
                        //当列表超过指定长度之后不再添加
                        //如果当前行字符串长度较短，则表明不是目标
                        if (blastLines.get(j).length()>3&&hitLines.size()<n) {
                            String[] oneLine = blastLines.get(j).split("\\s+");
                            hitLines.add(oneLine[1]);
                        }else {
                            break;
                        }
                    }
                    logger.info("select the first "+hitLines.size()+"hits from "+"\t"+i+" hits");
                    //System.out.println(OneLine[1]);
                }else if (blastLines.get(i).contains("***** No hits found *****")){
                    //TODO
                    //如果没有blast结果，则将自身代入
                    hitLines.add(blastRePath.substring(blastRePath.lastIndexOf(".")-9,blastRePath.lastIndexOf(".")));
                } else if (hitLines.size()>=n){
                    break;
                }else {
                    continue;
                }
            }
            return calRatio(hitLines,n);
        }else {
            return null;
        }
    }

    //根据Hit序列，查找数据库对应结构信息
    private double[] calRatio(List<String> hitLines,int n) throws IOException {
        List<String> hitSeqs=hitLines;
        //将结构信息存储在一个N行4列的矩阵中,n表示匹配链几个
        int[][] strcArr=new int[hitSeqs.size()][4];
        double totalFreqH=0.00;
        double totalFreqE=0.00;
        double totalFreqC=0.00;
        double totalFreqB=0.00;
        for (int i = 0; i <hitSeqs.size() ; i++) {
            strcArr[i]=nineMerMap.get(hitSeqs.get(i));
        }
        //每行的第一个元素的和为H的频次,以此类推
        for (int i = 0; i < strcArr.length ; i++) {
            try{
            //System.out.println(strcArr[i][0]+"\t"+strcArr[i][2]+"\t"+strcArr[i][1]);
            totalFreqH+=strcArr[i][0];
            totalFreqE+=strcArr[i][2];
            totalFreqC+=strcArr[i][1];
            //totalFreqB+=strcArr[i][3];
                }catch (NullPointerException e){
                return null;
            }

        }
        //这里，我们只记录三态信息
        double totalCount=totalFreqH+totalFreqE+totalFreqC;
        double ratioOfH=totalFreqH/totalCount;
        double ratioOfE=totalFreqE/totalCount;
        double ratioOfC=totalFreqC/totalCount;

        double[] ratioArr ={ratioOfH,ratioOfE,ratioOfC};
        return ratioArr;
    }
}
