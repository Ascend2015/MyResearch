package cn.tj212.yin.utils;

import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;

@Component
public class BlastServiceUtils {

    public static void blast(String dbName, String seqPath, String outPath, String pssmPath) throws IOException {
        File seqFile=new File(seqPath);
        String blastPath="E:\\blast-2.6.0+\\bin\\";
        String[] myfiles=seqFile.list();
        for (String myfile:myfiles
             ) {
            String cmd = "psiblast.exe"+" -evalue 10000 -num_iterations 3"+" -db "  + dbName+  " -query " + seqPath+File.separator+myfile+" -out " + outPath + myfile+
                    " -max_target_seqs 10"+" -out_ascii_pssm " + pssmPath + myfile.replace(".txt","") + ".pssm" ;
            Runtime runtime=Runtime.getRuntime();
            Process p=runtime.exec(cmd,null,new File(blastPath));
            System.out.println(myfile);
        }
    }

    //+" -max_target_seqs 10 "  + " -word_size 9 " + " pseudocount 9" + " -num_alignments 10"
    public static void main(String[] args){
        try {
            BlastServiceUtils.blast("D:\\makedb1\\all9mer","D:\\MyProteinData\\tinyTest\\shortfasta",
                    "D:\\MyProteinData\\tinyTest\\shortblast\\","D:\\MyProteinData\\tinyTest\\shortPssm\\");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
