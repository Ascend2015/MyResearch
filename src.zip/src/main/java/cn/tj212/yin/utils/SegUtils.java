package cn.tj212.yin.utils;

import Jama.Matrix;
import cn.tj212.yin.entity.Seg;

import java.util.ArrayList;
import java.util.List;

public class SegUtils {
    //加载blosum62代换得分矩阵
    //private static Matrix A = Matrix.Load("D:\\MyProgram\\testSqlLike\\testSqlLike\\testSqlLike\\blosum62\\BLOSUM62.csv");
    private String aminoLine = "ARNDCQEGHILKMFPSTWYVBZX*";

    //segScore方法对查询结果进行打分排序
    public List<Seg> seg7Score(List<Seg> segList, String segT)
    {
        segT = segT.replace("o", "*").replace("x", "*");
        List<Seg> newSegList = new ArrayList<Seg>();
        for(Seg seg : segList)
        {
            double score = 0;
            for (int i = 0; i < seg.getSeg().length(); i++)
            {
                double scoreIdx;
                if (i < 1 || i > 7)
                {
                    double subducIdx = 1.00 - (Math.abs(i - 4) / 10.00);
                    scoreIdx = subducIdx * calScore(seg.getSeg().substring(i, i+1), segT.substring(i,i+ 1));
                    score = score + scoreIdx;
                }
                else
                {
                    scoreIdx = calScore(seg.getSeg().substring(i, i+1), segT.substring(i, i+1));
                    score = score + scoreIdx;
                }
            }
            seg.setScore(score);
            if (score > 15)
            {
                newSegList.add(seg);
            }
        }
        return newSegList;
    }

    public List<Seg> seg5Score(List<Seg> segList, String segT)
    {
        segT = segT.replace("o", "*").replace("x", "*");
        List<Seg> newSegList = new ArrayList<Seg>();
        for (Seg seg : segList)
        {
            double score = 0;
            for (int i = 0; i < seg.getSeg().length(); i++)
            {
                double scoreIdx;
                if (i < 2 || i > 6)
                {
                    double subducIdx = 1.00 - (Math.abs(i - 4) / 10.00);
                    scoreIdx = subducIdx * calScore(seg.getSeg().substring(i, i+1), segT.substring(i, i+1));
                    score = score + scoreIdx;
                }
                else
                {
                    scoreIdx = calScore(seg.getSeg().substring(i, i+1), segT.substring(i, i+1));
                    score = score + scoreIdx;
                }
            }
            seg.setScore(score);
            if (score > 15)
            {
                newSegList.add(seg);
            }
        }
        return newSegList;
    }

    public List<Seg> seg3Score(List<Seg> segList, String segT)
    {
        segT = segT.replace("o", "*").replace("x", "*");
        List<Seg> newSegList = new ArrayList<Seg>();
        for (Seg seg : segList)
        {
            double score = 0;
            for (int i = 0; i < seg.getSeg().length(); i++)
            {
                double scoreIdx;
                if (i < 3 || i > 5)
                {
                    double subducIdx = 1.00 - (Math.abs(i - 4) / 10.00);
                    scoreIdx = subducIdx * calScore(seg.getSeg().substring(i, i+1), segT.substring(i, i+1));
                    //Console.WriteLine(subducIdx);
                    score = score + scoreIdx;
                }
                else
                {
                    scoreIdx = calScore(seg.getSeg().substring(i, i+1), segT.substring(i, i+1));
                    score = score + scoreIdx;
                }
            }
            seg.setScore(score);
            if (score > 15)
            {
                newSegList.add(seg);
            }
        }
        return newSegList;
    }

    public List<Seg> segScoreAll(List<Seg> segList, String segT)
    {
        segT = segT.replace("o", "*").replace("x", "*");
        List<Seg> newSegList = new ArrayList<Seg>();
        for (Seg seg : segList)
        {
            int score = 0;
            for (int i = 0; i < seg.getSeg().length(); i++)
            {
                double subducIdx = 1 - (Math.abs(i - 4) / 10);
                int scoreIdx = calScore(seg.getSeg().substring(i, i+1), segT.substring(i, i+1));
                score = score + scoreIdx;
            }
            seg.setScore(Double.valueOf(score));
            if (score > 15)
            {
                newSegList.add(seg);
            }
        }
        return newSegList;
    }


    private int calScore(String rowAmino, String columnAmino)
    {
        int rowIdx = aminoLine.indexOf(rowAmino);
        int columnIdx = aminoLine.indexOf(columnAmino);
        //double[] columnElement = A.GetColumn(columnIdx).ToArray();
        //int score = Convert.ToInt32(columnElement.ElementAt(rowIdx));
        //TODO
        return 0;
    }

}
