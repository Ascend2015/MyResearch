package cn.tj212.yin.utils;


import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

public class SPSSMUtils {
    /**
    public static void main(String[] args)
    {
        File file=new File("D:\\MyProteinData\\WholeChainBlast\\dsspToFastaBlast");
        String[] fnames = file.list();
        for (String fname : fnames)
        {
            System.out.println(fname);
            getProfile(fname, "D:\\MyProteinData\\fasta\\90percent2015strc", "D:\\MyProteinData\\SPSSM\90percent2015\\" + new File(fname));
        }
    }

    /// <summary>
    /// 得到Profile
    /// </summary>
    /// <param name="inputFile">输入的文件，单条，blastInfo格式</param>
    /// <param name="acc_libPath">模板库</param>
    /// <param name="outFilePath">输出路径</param>
    /**
    public static void getProfile(String inputFile, String acc_libPath, String outFilePath) throws IOException {
        //索引accProfile数组
        HashMap ht = new HashMap();
        String[] acclist = { "H","E","C","B"};
        for (int j = 0; j < acclist.length; j++)
        {
            ht.put(acclist[j], j);
        }


        //处理blast文件，得到Profile
        String QueryID = "";
        int Length = 0;

        List<String> strs = FileUtils.readLines(new File(inputFile),"UTF-8");
        int i = 0;
        while (!strs.get(i).startsWith("Query"))   //定位到Query
        {
            i++;
        }
        QueryID = strs.get(i).substring(6).trim();
        while (!strs.get(i).startsWith("Length"))
        {
            i++;
        }
        Length = Integer.parseInt(strs.get(i).substring(7));

        //定义profile的存储方式
            double[][] profile = new double[Length][4];//二维数组，用来记录未经统计的profile

        int countOfSbjcts = 0;//sbjct的数目
        String SbjctID = "";

        //acc
        String acc = ""; //为通过编译先行赋值

        while (!strs.get(i).startsWith("Lambda"))//Lambda 记录出现表示对齐信息记录的结束
        {
            if (countOfSbjcts == 11)//最多取x条记录
                break;

            String Query = "";
            String Sbjct = "";
            String Hit = "";//中间表示保守信息的一行

            if (strs.get(i).startsWith(">"))//新的sbjct ID  注意：有同一个ID存在多种对齐记录
            {
                SbjctID = strs.get(i).substring(2);
                acc = File.ReadAllLines(acc_libPath + "\\" + SbjctID + ".txt")[2];

                //if (SbjctID != QueryID)
                countOfSbjcts++;
            }
            //if (SbjctID.ToUpper() != QueryID.ToUpper()) //匹配到自己的就忽略
            //{
            //每次遇到Query处理三行
            if (strs.get(i).StartsWith("Query"))
            {
                int subStart = strs.get(i).IndexOf(strs.get(i).Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)[2]);//str中序列片段的起始索引                    
                int subLength = strs.get(i).Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)[2].Length;//序列片段的长度
                Query = strs.get(i).substring(subStart, subLength);
                Hit = strs[i + 1].substring(subStart, subLength);
                Sbjct = strs[i + 2].substring(subStart, subLength);

                int IndexQ = int.Parse(strs.get(i).Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)[1]);//Query起始位置
                int IndexS = int.Parse(strs[i + 2].Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)[1]);//Subjct起始位置

                int[] hit = new int[Length];//hit中记录的索引值从1开始,若为0，则说明没有匹配到

                for (int j = 0; j < subLength; j++)
                {
                    if (Hit[j] != ' ')
                    {
                        hit[IndexQ - 1] = IndexS;//索引值从1开始
                    }
                    if (Query[j] != '-')
                    {
                        IndexQ++;
                    }
                    if (Sbjct[j] != '-')
                    {
                        IndexS++;
                    }
                }


                //更新profile数组
                for (int j = 0; j < Length; j++)
                {
                    //如果hit中有0 元素，表示测试序列的相关位置没有找到对齐的sbjct
                    if (hit[j] == 0)
                    {
                        continue;
                    }
                    if (acc[hit[j] - 1].ToString() == "*")
                    {
                        continue;
                    }
                    else
                    {
                        if (ht.Contains(acc[hit[j] - 1].ToString()))
                        {
                            int index = (int)ht[acc[hit[j] - 1].ToString()];
                            profile[j, index]++;
                        }
                        else
                        {
                            Console.WriteLine("error\t" + inputFile);
                            Console.ReadLine();
                        }
                    }
                }

                i += 3;//到第三行，这句也可不要
            }
            //}

            i++;
        }

        //归一化并输出profile
        //格式按照二维数组的形式存放于文件中
        StreamWriter sw = new StreamWriter(outFilePath);

        for (int j = 0; j < Length; j++)
        {
            //归一化分母
            double total = 0;
            for (int k = 0; k < 4; k++)
            {
                total += profile[j, k];
            }

            String tmp = "";
            //total为0，说明该位置没有匹配到有用信息，4种状态都为0，
            if (total == 0)
            {
                tmp = "";
                for (int k = 0; k < 4; k++)
                {
                    tmp += "0.00\t";
                }

                tmp = tmp.substring(0, tmp.Length - 1);//去掉最后一个"\t"
            }
            else
            {
                for (int m = 0; m < 4; m++)
                {
                    tmp += (profile[j, m] / total).ToString("0.00") + "\t";
                }
                tmp = tmp.substring(0, tmp.Length - 1);//去掉最后一个"\t"
            }

            sw.WriteLine(tmp);
        }

        //for (int j = 0; j < Length; j++)
        //{
        //String tmp = "";
        //for (int k = 0; k < 3; k++)
        //{
        //tmp += profile[j, k].ToString()+'\t';
        //}
        //sw.WriteLine(tmp.substring(0, tmp.Length - 1));
        //}
        sw.Close();
    }
    public static void getSPSSM(){
        
    }
     */
}

