package cn.tj212.yin.utils;

import org.springframework.stereotype.Component;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Component
public class IOUtils {

    /**
     * 按行读取，返回行列表
     * @param inputDir
     * @return
     * @throws IOException
     */
    public static List<String> readFile(String inputDir) throws IOException {
        FileInputStream fis=new FileInputStream(inputDir);
        InputStreamReader isr=new InputStreamReader(fis);
        BufferedReader bfrSeq=new BufferedReader(isr);

        String seq="";
        List<String> lineList=new ArrayList<String>();
        while ((seq=bfrSeq.readLine())!=null){
            lineList.add(seq);
        }
        bfrSeq.close();
        isr.close();
        fis.close();
        return lineList;
    }

    /**
     * 追加写入
     * @param outDir
     * @param content
     * @throws IOException
     */
    public static void writeAppend(String outDir,String content) throws IOException {
        FileOutputStream fileOutputStream=new FileOutputStream(outDir,true);
        OutputStreamWriter outputStreamWriter=new OutputStreamWriter(fileOutputStream);
        outputStreamWriter.write(content+"\n");
        outputStreamWriter.flush();
        outputStreamWriter.close();
        fileOutputStream.close();
    }

    public static String[] listFile(String filePath){
        File file=new File(filePath);
        String[] fileArr=file.list();
        return fileArr;
    }

    public static void deleteFile(String filePath){
        File file=new File(filePath);
        String[] fileArr=file.list();
        for (int i = 0; i <fileArr.length ; i++) {
            new File(filePath+File.separator+fileArr[i]).delete();
            System.out.println(i+"/"+fileArr.length);
        }
    }

    public static List<String>[] randomFile(String directory){
        File file=new File(directory);
        List fileList=Arrays.asList(file.list());
        Collections.shuffle(fileList);
        List<String>[] sampleArr=new List[10];
        int sep=fileList.size()/5;
        int idx=0;
        for (int i = 0; i < fileList.size(); i+=sep) {
            int endIdx=i+sep;
            List<String> sampleList=null;
            if (endIdx>fileList.size())
                sampleList=fileList.subList(i,fileList.size());
            else
                sampleList=fileList.subList(i,endIdx);
            sampleArr[idx]=sampleList;
            idx++;
        }
        return sampleArr;
    }

    public static void switchLine(String filePath1,String filePath2,String mixFileDir) throws IOException {
        FileInputStream inputStream1=new FileInputStream(filePath1);
        InputStreamReader isr1=new InputStreamReader(inputStream1);
        BufferedReader buff1=new BufferedReader(isr1);
        String line1="";
        List<String> lineList1=new ArrayList<String>();
        while ((line1=buff1.readLine())!=null){
            lineList1.add(line1);
        }
        FileInputStream inputStream2=new FileInputStream(filePath2);
        InputStreamReader isr2=new InputStreamReader(inputStream2);
        BufferedReader buff2=new BufferedReader(isr2);
        String line2="";
        List<String> lineList2=new ArrayList<String>();
        while ((line2=buff2.readLine())!=null){
            lineList2.add(line2);
        }
        int i=0;
        StringBuffer content=new StringBuffer();
        for (String ele:lineList2
             ) {
            if (ele.contains("0.00\t0.00\t0.00")){
                lineList2.set(i,lineList1.get(i));
            }
            content.append(lineList2.get(i)+"\n");
            i++;
        }
        FileOutputStream fos=new FileOutputStream(mixFileDir);
        OutputStreamWriter osw=new OutputStreamWriter(fos);
        osw.write(content.toString());
        osw.flush();
        osw.close();
        buff2.close();
        isr2.close();
        inputStream2.close();
        buff1.close();
        isr1.close();
        inputStream1.close();
    }
}
