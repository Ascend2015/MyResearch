package cn.tj212.yin.utils;

public class StringUtil <T>{
    public String splitByTab(String seq){
        StringBuilder seqTab=new StringBuilder("");
        for (int i = 0; i <seq.length() ; i++) {
            seqTab.append(seq.substring(i,i+1)+"\t");
        }
        return seqTab.toString();
    }

}
