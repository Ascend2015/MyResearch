package cn.tj212.yin.utils;

import org.springframework.stereotype.Component;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

@Component
public class SeqUtils {
    private static final String AMINOACIDS = "ARNDCQEGHILKMFPSTWYVBZX*";

    private static String blusom62Path;

    public String getBlusom62Path() {
        return blusom62Path;
    }

    public void setBlusom62Path(String blusom62Path) {
        this.blusom62Path = blusom62Path;
    }

    /**
     * 获取目标氨基酸所在行的分值
     *
     * @param substring
     * @return
     * @throws IOException
     */
    public static String getBlusom62Score(String substring) throws IOException {
        //读取矩阵
        FileInputStream fis = new FileInputStream(blusom62Path);
        InputStreamReader isr = new InputStreamReader(fis);
        BufferedReader bfr = new BufferedReader(isr);

        List<String> blusom62List = new ArrayList<String>();
        String matrixLine = "";
        while ((matrixLine = bfr.readLine()) != null) {
            //矩阵列表
            blusom62List.add(matrixLine.replace("  ", " ").replace(" ", "\t"));
        }
        //目标氨基酸所在行数
//        for (int i = 0; i < blusom62List.size() ; i++) {
//            System.out.println(blusom62List.get(i));
//        }
        int index = AMINOACIDS.indexOf(substring);
        //该行分数
        String blusom62Score = blusom62List.get(index);
        return blusom62Score;
    }

    /**
     * 获取目标氨基酸与比对氨基酸的Blusom分值
     *
     * @param aminoTarget
     * @param aminoBlast
     * @return
     */
    public static String getAminoScoreInBlusom62(String aminoTarget, String aminoBlast) throws IOException {
        //获取目标氨基酸所在行的分值
        String aminoLine = getBlusom62Score(aminoTarget);
        int idx = AMINOACIDS.indexOf(aminoBlast);
        String[] scores = aminoLine.split("\t");
        String targetScore = scores[idx];
        return targetScore;
    }

    public static String splitByTab(String seq) {
        seq = seq.trim();
        StringBuffer seqTab = new StringBuffer("");
        for (int i = 0; i < seq.length(); i++) {
            seqTab.append(seq.substring(i, i + 1) + "\t");
        }
        return seqTab.toString();
    }

    //将蛋白转化为5位编码
    public static String convertToBinary(String amino) {
        Integer numberOfAmino = AMINOACIDS.indexOf(amino);
        String binAmino = Integer.toBinaryString(numberOfAmino);
        if (binAmino.length() < 5) {
            String tmp = "";
            for (int i = 0; i < 5 - binAmino.length(); i++) {
                tmp += "0";
            }
            binAmino = tmp + binAmino;
            return binAmino;
        }
        return binAmino;
    }

    /**
     * public static String convertToOrthoCode(String str){
     * String[] strArr=str.split("\t");
     * StringBuilder tmp=new StringBuilder("");
     * for (int i=0;i<21;i++) {
     * strArr[i]=convertToOrthoCode((strArr[i]));
     * }
     * for (int i = 0; i < strArr.length; i++) {
     * tmp.append(strArr[i]);
     * }
     * return new String(tmp.toString());
     * }
     */

    public static String getBlusomScoreBySeg(String segment,String blastSeg){
        String score="";
        segment=segment.replace("o","*").replace("x","*");
        blastSeg=blastSeg.replace("o","*").replace("x","*");
        for (int i = 0; i <segment.length() ; i++) {
            String targetAmino=segment.substring(i,i+1);
            String blastAmino=blastSeg.substring(i,i+1);
            try {
                score=score+getAminoScoreInBlusom62(targetAmino,blastAmino)+"\t";
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return score;
    }

    public static String toOrthoCode(String amino) {
        if (amino.equals("x") || amino.equals("o")) {
            amino = "*";
        }
        String code = "0000000000000000000000";
        int index = AMINOACIDS.indexOf(amino);
        char[] codeArr = code.toCharArray();
        codeArr[index] = '1';
        code = new String(codeArr);
        return code;
    }

    public static void cutNine(String sequence, String cutdownPath) throws IOException {
        String writePath = cutdownPath;
        File file1=new File(writePath);
        if (!file1.isDirectory())
        {
            file1.mkdir();
        }
        sequence = "oooo" + sequence + "xxxx";
        for (int i = 4; i < sequence.length()-4; i++) {
            String segment = sequence.substring(i - 4, i+5);
            OutputStream os=new FileOutputStream(writePath + "\\" + segment + ".txt");
            OutputStreamWriter osw = new OutputStreamWriter(os);
            BufferedWriter bfw=new BufferedWriter(osw);
            String content = ">" + segment+"\n"+segment;
            bfw.write(content);
            bfw.close();
        }
    }
}
