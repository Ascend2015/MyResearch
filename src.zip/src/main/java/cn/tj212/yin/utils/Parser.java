package cn.tj212.yin.utils;

import cn.tj212.yin.entity.SomePath;
import cn.tj212.yin.utils.Read9merStrcUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import cn.tj212.yin.utils.IOUtils;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class Parser {

    public void getTrainingSet(String pssmPath, String secStrcPath, String outputPath, String spssmPath) throws IOException {
        File pssmFile = new File(pssmPath);
        String[] pssmID = pssmFile.list();
        FileOutputStream fos = new FileOutputStream(outputPath, true);
        OutputStreamWriter osw = new OutputStreamWriter(fos);
        for (int i = 0; i < pssmID.length; i++) {
            System.out.println(pssmID[i]);
            List<String> PSSMLine = parsePSSM(pssmPath + File.separator + pssmID[i]);
            String sequence = parseDSSP(secStrcPath + File.separator + pssmID[i].substring(0, pssmID[i].lastIndexOf("."))).get(1);
            String secStrc = parseDSSP(secStrcPath + File.separator + pssmID[i].substring(0, pssmID[i].lastIndexOf("."))).get(2);
            List<String> SPSSMList = getSPSSM(spssmPath + File.separator + pssmID[i].substring(0, pssmID[i].lastIndexOf("."))+".txt");
            String triState = "";
            System.out.println(PSSMLine.size() + "\t" + secStrc.length() + "\t");
            sequence ="oooo"+sequence+"xxxx";
            secStrc ="oooo"+secStrc+"xxxx";
            for (int j = 4; j < sequence.length() -4; j++) {
                triState = secStrc.substring(j, j + 1);
                String PSSMContent = PSSMLine.get(j-4).replace("   ", "\t").replace("  ", "\t").replace(" ", "\t");
                String outputLine = sequence.substring(j, j + 1) + "\t" +SeqUtils.splitByTab(sequence.substring(j-4,j+5)) + PSSMContent
                        + "\t" + SPSSMList.get(j-4) + "\t" + triState + "\n";
                //String outputLine=PSSMContent
                //       +"\t"+triState+"\n";
                osw.write(outputLine.replace("\t\t", "\t"));
            }
            osw.write("\n");
        }
        osw.close();
        fos.close();
    }

    public void getTrainingSetOnlyPssm(String pssmPath, String secStrcPath, String outputPath ) throws IOException {
        File pssmFile = new File(pssmPath);
        String[] pssmID = pssmFile.list();
        FileOutputStream fos = new FileOutputStream(outputPath, true);
        OutputStreamWriter osw = new OutputStreamWriter(fos);
        for (int i = 0; i < pssmID.length; i++) {
            System.out.println(pssmID[i]);
            List<String> PSSMLine = parsePSSM(pssmPath + File.separator + pssmID[i]);
            String sequence = parseDSSP(secStrcPath + File.separator + pssmID[i].substring(0, pssmID[i].lastIndexOf("."))).get(1);
            String secStrc = parseDSSP(secStrcPath + File.separator + pssmID[i].substring(0, pssmID[i].lastIndexOf("."))).get(2);
            String triState = "";
            System.out.println(PSSMLine.size() + "\t" + secStrc.length() + "\t");
            sequence ="oooo"+sequence+"xxxx";
            secStrc ="oooo"+secStrc+"xxxx";
            for (int j = 4; j < sequence.length() -4; j++) {
                triState = secStrc.substring(j, j + 1);
                String PSSMContent = PSSMLine.get(j-4).replace("   ", "\t").replace("  ", "\t").replace(" ", "\t");
                String outputLine = sequence.substring(j, j + 1) + "\t" +SeqUtils.splitByTab(sequence.substring(j-4,j+5)) + PSSMContent
                        + "\t" + triState + "\n";
                osw.write(outputLine.replace("\t\t", "\t"));
            }
            osw.write("\n");
        }
        osw.close();
        fos.close();
    }



    public void getTrainingSet(String pssmPath, String secStrcPath, String output, String spssmPath, String blastPath) throws IOException {
        File pssmFile = new File(pssmPath);
        String[] pssmID = pssmFile.list();
        FileOutputStream fos = new FileOutputStream(output, true);
        OutputStreamWriter osw = new OutputStreamWriter(fos);
        for (int i = 0; i < pssmID.length; i++) {
            System.out.println(pssmID[i]);
            List<String> PSSMLine = parsePSSM(pssmPath + File.separator + pssmID[i]);
            String secStrc = parseDSSP(secStrcPath + File.separator + pssmID[i].substring(0, pssmID[i].lastIndexOf("."))).get(2);
            //todo
            String sequence = parseDSSP(secStrcPath + File.separator + pssmID[i].substring(0, pssmID[i].lastIndexOf("."))).get(1);
            List<String> blastList = getBlastResultBySequence(blastPath, sequence);
            List<String> SPSSMList = getSPSSM(spssmPath + File.separator + pssmID[i].substring(0, pssmID[i].lastIndexOf(".")));
            String triState = "";
            System.out.println(PSSMLine.size() + "\t" + secStrc.length() + "\t");

            for (int j = 0; j < PSSMLine.size(); j++) {
                triState = secStrc.substring(j, j + 1);
                String PSSMContent = PSSMLine.get(j).replace("   ", "\t").replace("  ", "\t").replace(" ", "\t");
                String outputLine = sequence.substring(j, j + 1) + "\t" + blastList.get(j) + PSSMContent
                        + "\t" + SPSSMList.get(j) + "\t" + triState + "\n";
                osw.write(outputLine.replace("\t\t", "\t"));
            }
            osw.write("\n");
        }
        osw.close();
        fos.close();
    }

    public void trainingSetOnlyPSSM(){

    }

    private List<String> getBlastResultBySequence(String blastPath, String sequence) throws IOException {
        List<String> blusomScoreList = new ArrayList<String>();
        sequence = "oooo" + sequence + "xxxx";
        for (int i = 0; i < sequence.length() - 8; i++) {
            String segment = sequence.substring(i, i + 9);
            String segBlast = findFirstHit(blastPath, segment).replace("o","*").replace("x","*");
            System.out.println(segBlast+"\t"+segment);
            String scoreLine="";
            for (int j = 0; j < segment.length(); j++) {
                String target = segment.substring(j, j + 1);
                String match = segBlast.substring(j, j + 1);
                if (target.equals("o") || target.equals("x"))
                    target = "*";
                String score = SeqUtils.getAminoScoreInBlusom62(target, match);
                scoreLine=scoreLine+score+"\t";
            }
            blusomScoreList.add(scoreLine);
        }
        return blusomScoreList;
    }

    private String findFirstHit(String blastPath, String segment) throws IOException {
        try{
            List<String> blastFileContent = IOUtils.readFile(blastPath+File.separator+segment+".txt");
            String blastFirstHit = "";
            for (int i = 0; i < blastFileContent.size(); i++) {
                if (blastFileContent.get(i).startsWith(">")) {
                    blastFirstHit = blastFileContent.get(i).substring(2, 2 + segment.length());
                    System.out.println(blastFirstHit);
                    return blastFirstHit;
                }
            }
        }catch (FileNotFoundException e){
            return segment;
        }
        //否则返回查询序列本身
        return segment;
    }

    private String getNewSPSSM(String blastPath, int n) throws IOException {
        Read9merStrcUtils r = new Read9merStrcUtils();
        double[] ratio = r.readBlast(blastPath, n);
        return ratio[0] + "\t" + ratio[1] + "\t" + ratio[2];
    }

    //todo
    private List<String> getSPSSM(String spssmPath) throws IOException {
        List<String> SPSSMList = IOUtils.readFile(spssmPath );
        return SPSSMList;
    }

    public void trainingSetOnlySPSSM(String profilePath, String spssmPath, String outputPath) throws IOException {
        String[] profileIdArr = IOUtils.listFile(profilePath);
        for (int i = 0; i < profileIdArr.length; i++) {
            System.out.println(i + "/" + profileIdArr.length + "\t" + profileIdArr[i]);
            String sequence = parseDSSP(profilePath + File.separator + profileIdArr[i].substring(0, profileIdArr[i].lastIndexOf("."))).get(1);
            String secStrc = parseDSSP(profilePath + File.separator + profileIdArr[i].substring(0, profileIdArr[i].lastIndexOf("."))).get(2);
            List<String> spssmLine = IOUtils.readFile(spssmPath + File.separator + profileIdArr[i].substring(0, profileIdArr[i].lastIndexOf(".")) + ".txt");
            StringBuilder outContent = new StringBuilder("");
            for (int j = 0; j < spssmLine.size(); j++) {
                outContent.append(sequence.substring(j, j + 1) +  "\t" + spssmLine.get(j) + "\t" + secStrc.substring(j, j + 1) + "\n");
            }
            IOUtils.writeAppend(outputPath, outContent.toString() + "\n");
        }
    }

    public void trainSetWithCtxPssmAndSPSSM(String profilePath, String pssmPath,String spssmPath, String outputPath) throws IOException {
        String[] profileIdArr = IOUtils.listFile(profilePath);
        for (int i = 0; i < profileIdArr.length; i++) {
            System.out.println(i + "/" + profileIdArr.length + "\t" + profileIdArr[i]);
            String sequence = parseDSSP(profilePath + File.separator + profileIdArr[i].substring(0, profileIdArr[i].lastIndexOf("."))).get(1);
            String secStrc = parseDSSP(profilePath + File.separator + profileIdArr[i].substring(0, profileIdArr[i].lastIndexOf("."))).get(2);
            List<String> pssmlist=parsePSSM(pssmPath+File.separator+profileIdArr[i].substring(0, profileIdArr[i].lastIndexOf("."))+".pssm");
            List<String> spssmLine = IOUtils.readFile(spssmPath + File.separator + profileIdArr[i].substring(0, profileIdArr[i].lastIndexOf(".")));
            StringBuilder outContent = new StringBuilder("");
            sequence ="oooo"+sequence+"xxxx";
            secStrc ="oooo"+secStrc+"xxxx";
            for (int j = 4; j < sequence.length() -4; j++) {
                String triState = secStrc.substring(j, j + 1);
                String PSSMContent = pssmlist.get(j-4).replace("   ", "\t").replace("  ", "\t").replace(" ", "\t");
                String outputLine = sequence.substring(j, j + 1) + "\t" +SeqUtils.splitByTab(sequence.substring(j-4,j+5)) + PSSMContent
                         + spssmLine.get(j-4) + "\t" + triState + "\n";
                outContent.append(outputLine);
            }
            IOUtils.writeAppend(outputPath, outContent.toString() + "\n");
        }
    }

    /**
     * 在PSSM中获得序列、序列的上下文、序列的PSSM矩阵
     *
     * @param pssmDir
     */
    public List<String> parsePSSM(String pssmDir) throws IOException {

        FileInputStream fisPSSM = new FileInputStream(pssmDir);
        InputStreamReader pssmIn = new InputStreamReader(fisPSSM);
        BufferedReader pssmBr = new BufferedReader(pssmIn);

        List<String> lineList = new ArrayList<String>();
        String amino = "";
        StringBuilder seq = new StringBuilder("");
        List<String> PSSM = new ArrayList<String>();
        String line = "";
        String newLine = "";

        List<String> newLineList = new ArrayList<String>();
        while ((line = pssmBr.readLine()) != null) {
            lineList.add(line);
            //newLine=amino+PSSM;
        }
        pssmBr.close();
        pssmIn.close();
        fisPSSM.close();
        for (int i = 3; i < lineList.size() - 1; i++) {
            if (lineList.get(i).length() > 1) {
                amino = lineList.get(i).substring(6, 7);
                seq = seq.append(amino);
                //System.out.println(lineList.get(i));
                //System.out.println(amino+"\t"+lineList.get(i).substring(10,70));
                String[] pssmArr = lineList.get(i).split(" ");
                StringBuilder tmp = new StringBuilder("");
                Pattern p = Pattern.compile("-*\\d+(\\.\\d+)?");
                List<String> tmpList = new ArrayList<String>();
                for (String pssm : pssmArr
                        ) {
                    Matcher m = p.matcher(pssm);
                    if (m.find()) {
                        tmpList.add(m.group(0));
                    }
                }
                for (int j = 1; j < 21; j++) {
                    tmp.append(tmpList.get(j) + "\t");
                }
                //System.out.println(tmp);
                PSSM.add(tmp.toString());
            } else {
                break;
            }
        }
        seq = new StringBuilder("oooo" + seq.toString() + "xxxx");
        for (int j = 4; j < seq.toString().length() - 4; j++) {
//            //生成相应的上下文变量
//            char[] charArr = seq.toString().substring(j - 4, j + 5).toCharArray();
//            String ctx = "";
//            for (int k = 0; k < charArr.length; k++) {
//                ctx = ctx + charArr[k] + "\t";
//            }
//            TODO
//            可以在这里加入短链的SPSSM
//            String blastPath="D:\\MyProteinData\\tinyTest\\spssm4";
//            String shortSpssm=getNewSPSSM(blastPath+File.separator+seq.toString().substring(j-4,j+5)+".txt",1);
            //在此将上下文去除测试对预测结果的影响
            //newLine = seq.toString().substring(j, j + 1) + "\t" + ctx + "\t" + PSSM.get(j - 4);
            //加上blusom62理论值
//            newLine = seq.toString().substring(j, j + 1) + "\t" + addBlusom62(ctx.replace("\t", "")) + "\t" + PSSM.get(j - 4);
            newLine = PSSM.get(j - 4);
            newLineList.add(newLine);
        }
        return newLineList;
    }

    /**
     * 从DSSP中获得序列及其对应的真实结构
     *
     * @param strcDir
     */
    public List<String> parseDSSP(String strcDir) throws IOException {
        String secStrc = "";
        FileInputStream fis = new FileInputStream(strcDir + ".txt");
        InputStreamReader isrStrc = new InputStreamReader(fis);
        BufferedReader bfrStrc = new BufferedReader(isrStrc);
        String strcLine = "";
        List<String> lineList = new ArrayList<String>();
        while ((strcLine = bfrStrc.readLine()) != null) {
            lineList.add(strcLine);
        }
        bfrStrc.close();
        isrStrc.close();
        fis.close();
        return lineList;
    }

    public void generate9merFasta(String secStrcPath, String outpath) {
        try {
            File strcFile = new File(secStrcPath);
            String[] strcList = strcFile.list();
            for (int i = 0; i < strcList.length; i++) {
                System.out.println((i + 1) + "/" + strcList.length);
                String seq = parseDSSP(secStrcPath + File.separator + strcList[i].substring(0, strcList[i].lastIndexOf("."))).get(1);
                String secstrc = parseDSSP(secStrcPath + File.separator + strcList[i].substring(0, strcList[i].lastIndexOf("."))).get(2);
                seq = "oooo" + seq + "xxxx";
                secstrc = "oooo" + secstrc + "xxxx";
                for (int j = 4; j < seq.length() - 4; j++) {
                    try {
                        String segment = seq.substring(j - 4, j + 5);
                        String strc = secstrc.substring(j - 4, j + 5);
                        FileOutputStream fileOutputStream = new FileOutputStream(outpath + File.separator + segment + ".txt");
                        File file = new File(outpath + "_strc");
                        if (!(file.exists()))
                            file.mkdir();
                        FileOutputStream shortStrcOut = new FileOutputStream(outpath + "_strc" + File.separator + segment + ".txt");
                        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(fileOutputStream);
                        OutputStreamWriter shortStrcWriter = new OutputStreamWriter(shortStrcOut);
                        outputStreamWriter.write(">" + segment + "\n" + segment + "\n");
                        shortStrcWriter.write(">" + segment + "\n" + segment + "\n" + strc + "\n");
                        outputStreamWriter.flush();
                        shortStrcWriter.flush();
                        outputStreamWriter.close();
                        shortStrcWriter.close();
                        shortStrcOut.close();
                        fileOutputStream.close();
                    } catch (StringIndexOutOfBoundsException e) {
                        e.printStackTrace();
                        System.out.println(seq);
                        continue;
                    }
                    //System.out.println(segment);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String addBlusom62(String segment) throws IOException {
        StringBuilder scoreLine = new StringBuilder("");
        for (int i = 0; i < segment.length(); i++) {
            String target = segment.substring(i, i + 1);
            if (target.equals("o") || target.equals("x"))
                target = "*";
            String score = SeqUtils.getAminoScoreInBlusom62(target, target);
            scoreLine.append(score + "\t");
        }
        return scoreLine.toString();
    }
}
