package cn.tj212.yin.exception;

public class NoHitsFoundException extends Exception{
    public NoHitsFoundException(String message) {
        super(message);
    }

    public NoHitsFoundException(){
    }

    public NoHitsFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    public String getMessage(){
        return super.getMessage();
    }


}
