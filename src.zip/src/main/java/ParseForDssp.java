import cn.tj212.yin.utils.IOUtils;
import org.junit.Test;

import java.io.*;
import java.util.ArrayList;

public class ParseForDssp {
    //20个氨基酸的字母表示
    private static String AMINO_ACIDS = "ACDEFGHIKLMNPQRSTVWY";
    //以下对应二级结构元素C
    String strcCharC = "TSC";
    String strcCharH = "HGIB";
    String strcCharE = "E";

    /**
     * @param dsspPath dssp所在路径
     * @param
     */
    public void readData(String dsspPath, String picesPath, String outPath, String singlePath) throws IOException {

        File dsspDir = new File(dsspPath);
        String[] dsspList = dsspDir.list();

        FileInputStream fisPices = new FileInputStream(picesPath);
        InputStreamReader picesIn = new InputStreamReader(fisPices);
        BufferedReader picesBr = new BufferedReader(picesIn);

        String fastaOut = "";
        ArrayList<String> IdList = new ArrayList<String>();
        String idLine = "";
        while ((idLine = picesBr.readLine()) != null) {
            IdList.add(idLine);
        }

        for (int i = 0; i < IdList.size(); i++) {
            FileInputStream dsspIn = new FileInputStream(dsspPath + "\\" + IdList.get(i).substring(0, 4) + ".dssp");
            InputStreamReader isrDssp = new InputStreamReader(dsspIn);
            BufferedReader bfrDssp = new BufferedReader(isrDssp);
            String dsspLine = "";
            String amino = "";
            String strc = "";
            int j = 0;
            System.out.println(IdList.get(i));
            ArrayList<String> dsspLineList = new ArrayList<String>();
            while ((dsspLine = bfrDssp.readLine()) != null) {
                dsspLineList.add(dsspLine);
                //System.out.println(dsspLine);
            }
            for (int k = 28; k < dsspLineList.size(); k++) {
                //System.out.println(dsspLineList.get(k).substring(13,14)+"\t"+dsspLineList.get(k).substring(11,12));
                boolean isAmino = AMINO_ACIDS.contains(dsspLineList.get(k).substring(13, 14));
                boolean chainTag = IdList.get(i).substring(4, 5).equals(dsspLineList.get(k).substring(11, 12));
                /**
                 * 判定是否为不定氨基酸;判定是否与PICES结果为同一条链
                 */
                if (isAmino && chainTag) {
                    amino = amino + dsspLineList.get(k).substring(13, 14);
                    String s = dsspLineList.get(k).substring(16, 17);
                    s=transToQ3(s);
                    strc = strc + s;
                }
            }

            fastaOut = fastaOut + ">" + IdList.get(i).substring(0, 5) + "\n" + amino + "\n";
            singleFasta(singlePath, IdList.get(i).substring(0, 5), amino, strc);
            System.out.println(amino);
            amino = "oooo" + amino + "xxxx";
            strc = "oooo" + strc + "xxxx";
            for (int k = 0; k < amino.length() - 10; k++) {
                String seg = amino.substring(k, k + 9);
                String s = strc.substring(k + 4, k + 5);

                String line = seg.substring(4, 5);
                char[] charArr = seg.toCharArray();
                for (int l = 0; l < 9; l++) {
                    line = line + "\t" + charArr[l];
                }
            }
        }
        FileOutputStream fos = new FileOutputStream(outPath);
        OutputStreamWriter osw = new OutputStreamWriter(fos);
        osw.write(fastaOut);
        osw.close();
    }

    private void singleFasta(String singlePath, String ID, String sequence, String strc) throws IOException {
        FileOutputStream fos = new FileOutputStream(singlePath + File.separator + ID + ".txt");
        File file = new File(singlePath + "strc");
        if (!file.exists())
            file.mkdir();
        //输出到模板文件夹
        FileOutputStream fostrc = new FileOutputStream(singlePath + "strc" + File.separator + ID + ".txt");
        OutputStreamWriter osw = new OutputStreamWriter(fos);
        OutputStreamWriter oswstrc = new OutputStreamWriter(fostrc);
        String fastaStrcOut = ">" + ID + "\n" + sequence + "\n" + strc;
        String fastaOut = ">" + ID + "\n" + sequence;
        oswstrc.write(fastaStrcOut);
        osw.write(fastaOut);
        osw.flush();
        oswstrc.flush();
        oswstrc.close();
        osw.close();
    }

    public void parseCaspDssp(String dsspPath, String outPath, String singlePath) throws IOException {
        String[] dsspFileList = IOUtils.listFile(dsspPath);

        StringBuilder fastaOut = new StringBuilder("");
        for (int i = 0; i < dsspFileList.length; i++) {
            FileInputStream dsspIn = new FileInputStream(dsspPath + "\\" + dsspFileList[i]);
            InputStreamReader isrDssp = new InputStreamReader(dsspIn);
            BufferedReader bfrDssp = new BufferedReader(isrDssp);
            String dsspLine = "";
            String amino = "";
            String strc = "";
            int j = 0;
            System.out.println(dsspFileList[i]);
            ArrayList<String> dsspLineList = new ArrayList<String>();
            while ((dsspLine = bfrDssp.readLine()) != null) {
                dsspLineList.add(dsspLine);
                //System.out.println(dsspLine);
            }
            for (int k = 28; k < dsspLineList.size(); k++) {
                //System.out.println(dsspLineList.get(k).substring(13,14)+"\t"+dsspLineList.get(k).substring(11,12));
                boolean isAmino = AMINO_ACIDS.contains(dsspLineList.get(k).substring(13, 14));
                /**
                 * 判定是否为不定氨基酸
                 */
                if (isAmino) {
                    amino = amino + dsspLineList.get(k).substring(13, 14);
                    String s = dsspLineList.get(k).substring(16, 17);
                    s=transToQ3(s);
                    strc = strc + s;
                }
            }

            fastaOut = fastaOut.append(">" + dsspFileList[i].substring(0, dsspFileList[i].lastIndexOf(".")) + "\n" + amino + "\n");
            singleFasta(singlePath, dsspFileList[i].substring(0, dsspFileList[i].lastIndexOf(".")), amino, strc);
            System.out.println(amino);
            amino = "oooo" + amino + "xxxx";
            strc = "oooo" + strc + "xxxx";
            for (int k = 0; k < amino.length() - 10; k++) {
                String seg = amino.substring(k, k + 9);
                String s = strc.substring(k + 4, k + 5);
                String line = seg.substring(4, 5);
                char[] charArr = seg.toCharArray();
                for (int l = 0; l < 9; l++) {
                    line = line + "\t" + charArr[l];
                }
            }
        }
        FileOutputStream fos = new FileOutputStream(outPath);
        OutputStreamWriter osw = new OutputStreamWriter(fos);
        osw.write(fastaOut.toString());
        osw.close();

    }

    private String transToQ3(String s){
        if (strcCharC.indexOf(s) > -1) {
            s = "C";
        } else if (strcCharH.indexOf(s) > -1) {
            s = "H";
        } else if (strcCharE.indexOf(s) > -1) {
            s = "E";
        } else{
            s = "B";
        }
        return s;
    }

    @Test
    public void test() {
        ParseForDssp p = new ParseForDssp();
        String dsspPath = "J:\\SciencePDB\\scienceDssp";
        String picesPath = "J:\\SciencePDB\\sciID.txt";
        String outPath = "J:\\SciencePDB\\6ezo.txt";
        String singlePath = "J:\\SciencePDB\\science";
        try {
            p.readData(dsspPath, picesPath, outPath, singlePath);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
