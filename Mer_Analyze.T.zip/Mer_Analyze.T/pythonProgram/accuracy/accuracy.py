import os
def calculate(fileDir):
        f=open(fileDir,"r",True)
        line=[]
        for i in f.readlines():
            i=i.strip("\n")
            if len(i)>0:
                line.append(i)
        k=0
        #print(line)
        for i in range(0,len(line)-1):
            print(line[i][-1]+"\t"+line[i][-3])
            if line[i][-1]==line[i][-3]:
                k=k+1
        accuracy=k/len(line)
        print( accuracy)
                #allLines[i]
if __name__ == '__main__':
    calculate(r"C:\Users\Administrator\Desktop\20170510remodelyuceRemoveBlank.txt")