﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Data.OleDb;
using System.IO;
using System.Collections;

namespace Mer_Analyze
{
    public partial class Form1 : Form
    {
        private string path;
        public Form1()
        {
            InitializeComponent();
        }


        public void readData(string path)
        {
            StreamReader pisces = new StreamReader(openFileDialog1.FileName);       //链ID数据流
            string temp= pisces.ReadToEnd();            //一次读完
            string[] chain=temp.Split('\n');            //链ID存入数组
            DirectoryInfo dir = new DirectoryInfo(path);
            FileInfo[] ID = dir.GetFiles();
            int total = ID.Length;
            int current = 0;
            for (int i=0;i<chain.Length;i++)           //对存放链ID的数组进行遍历
            {
                Console.WriteLine(chain[i].Substring(0, 4));
                StreamReader sr = new StreamReader(path + "/" + chain[i].Substring(0, 4)+".dssp");//根据链ID打开文件
                try
                {
                    List<string> lineList = new List<string>();
                    while (sr.Peek()>0)
                    {
                        string line = sr.ReadLine();
                        lineList.Add(line);
                    }
                    string s2 = "ACDEFGHIKLMNPQRSTVWY";
                    string amino = "";
                    string prots = "";
                    for (int k = 28; k < lineList.Count();k++) { 
                    if (s2.IndexOf(lineList[k][13]) > -1&&chain[i].Substring(4,1).Equals(lineList[k].Substring(11,1)))
                    {
                            amino = amino + lineList[k][13];    
                            prots = prots + lineList[k][16];
                        }
                    }
                    amino = "oooo" + amino + "xxxx";
                    prots = "oooo" + prots + "xxxx";
                    Console.WriteLine(amino);
                    Console.WriteLine(prots);
                    for (int j = 0; j < amino.Length - 8; j++)
                    {
                        string seg = amino.Substring(j,9);
                        char c = prots[j + 4];
                        saveOneSeg(seg, c);
                        Console.WriteLine(seg.Substring(4, 1)+"\t"+c);
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message+ "\n"+chain[i].Substring(0, 4));          
                }
                finally
                {
                    sr.Close();
                    current++;
                    if (current >= (chain.Length-1)) {
                        MessageBox.Show("Count Finished.");
                    }
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            //读文件，统计
            path = folderBrowserDialog1.SelectedPath;
            readData(path);//读取Dssp文件
        }
    
     void saveOneSeg(string seg, char c)
    {
        sqlConnection1.Close();
        sqlConnection1.Open();
        string sql = "select * from Example where seg='" + seg + "'";
        SqlCommand cmd = new SqlCommand(sql, sqlConnection1);
        SqlDataReader dr = cmd.ExecuteReader();

            string ssC = "TSC";
            string ssH = "HGIB";
            if (ssC.IndexOf(c) > -1)
            {
                c = 'C';
            }
            else if (ssH.IndexOf(c) > -1)
            {
                c = 'H';
            }
            else if (c == ' ')
            {
                c = 'B';
            }
            else if (c == 'E')
            {
                c = 'E';
            }
            if (dr.Read())
        {
                //准备update语句
            string update = "update Example set " + c + "=" + c + "+1" + "and create_time = default" + " where seg='" + seg + "'";
            SqlCommand cmd1 = new SqlCommand(update, sqlConnection1);
                dr.Close();
                cmd1.ExecuteNonQuery();
        }
        else
        {
            //插入语句
            string va = "0,0,0,0";
            if (c == 'H')
            {
                va = "1,0,0,0";
            }
            else if (c == 'C')
            {
                va = "0,1,0,0";
            }
            else if (c == 'E')
            {
                va = "0,0,1,0";
            }
            else if (c == 'B')
            {
                va = "0,0,0,1";
            }
            string insert = "insert into Example values(" + "'"+seg +"'"+ "," + va +","+"default"+ ")";
            SqlCommand cmd2 = new SqlCommand(insert, sqlConnection1);
            dr.Close();
            cmd2.ExecuteNonQuery();
        }
            dr.Close();
            sqlConnection1.Close();
    }

    private void sqlConnection1_InfoMessage(object sender, System.Data.SqlClient.SqlInfoMessageEventArgs e)
    {

    }

    private void button2_Click(object sender, EventArgs e)
    {
        folderBrowserDialog1.ShowDialog();
        textBox1.Text = folderBrowserDialog1.SelectedPath;    //获得链的ID所在的路径
    }

    private void textBox1_TextChanged(object sender, EventArgs e)
    {
           
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            textBox2.Text = openFileDialog1.FileName;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
